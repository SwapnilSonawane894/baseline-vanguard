import moment from "moment"; console.log(moment().format());
