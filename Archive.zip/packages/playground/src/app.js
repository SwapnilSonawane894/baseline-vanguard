// See https://svelte.dev/docs/kit/types
// for information about these interfaces