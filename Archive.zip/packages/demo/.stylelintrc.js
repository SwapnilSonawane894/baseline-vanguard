module.exports = {
  "plugins": [
    "../stylelint-plugin-baseline"
  ],
  "rules": {
    "baseline/detect-unsupported-css-features": true
  }
};